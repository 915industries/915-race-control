# Race Control Time Attack – Theme Selector Edition

This project packages the **Race Control Time Attack** web application with
support for multiple bespoke UI themes and a settings menu to choose between
them.  The goal is to provide a premium "million‑dollar" look while
preserving all of the underlying race logic from the original app.  Users can
toggle between six distinct colour schemes at runtime and their choice will
persist across sessions using the browser's local storage.

## Getting started

1. Copy the contents of this folder to the root of your existing Race
   Control Time Attack project (replace the original `index.html` with
   this `index.html` and copy the `themes` and `renderings` directories).
2. Ensure that the `<script>` and `<div id="themeMenu">` blocks remain in
   your HTML file when merging with the original markup.  They provide
   the settings button and handle theme switching.
3. Host the static files on your web server as before.  No build step is
   required.

## Themes included

| Key        | Name               | Description                                                  |
|-----------|--------------------|--------------------------------------------------------------|
| black_ops | **Black Ops GT**    | Dark graphite base with red accents.  Channel endurance‑race |
|           |                    | telemetry systems.                                           |
| hypercar  | **Hypercar HUD**    | Deep blacks with cyan highlights for a futuristic feel.      |
| tactical  | **Tactical Command**| Militaristic dark palette with warm amber highlights.        |
| lemans    | **Le Mans Pro**     | Light theme with minimal colour for professional settings.   |
| nexus     | **Race Control Nexus** | Cinematic dark theme with deep blue accents.               |
| analog    | **Analog Future**   | Retro‑futuristic vibe with warm oranges and browns.          |

Each theme is defined by its own CSS file in the `themes` directory.  To add
more themes, simply drop a new CSS file into `themes/` and add an entry to
the `THEMES` array in `index.html` with a unique `key`, friendly `label`, and
file name.

## Settings menu

The tiny ⚙ icon in the top right corner of the app toggles the theme
selection menu.  Clicking a theme name immediately applies the style and
saves your choice.  The selected theme persists across page loads via
`localStorage`.

## Renderings

The `renderings` directory contains quick visualisations of each screen of
the app across all six themes.  These are not fully interactive but
demonstrate the colour treatments.  To generate fresh renderings, run

```bash
python generate_renderings.py
```

if you have the Python dependencies installed.  The script applies a semi‑
transparent colour overlay and a branded logo to the original screenshots.

## License

All custom theme definitions in this package are released under the MIT
License.  The original Race Control Time Attack source retains its existing
copyright and licensing.